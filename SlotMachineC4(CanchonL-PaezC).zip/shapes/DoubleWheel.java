import java.util.List;
import java.util.Map;
public class DoubleWheel extends Wheel{
    public DoubleWheel(int index, List<Wheel> row, Map<String, Symbol> registry){
        super(index, row, registry, "double", "mediumseagreen");
    }
    public void spin(List<String> catalog, int steps){
        super.spin(catalog, 2 * row.size());
    }
}