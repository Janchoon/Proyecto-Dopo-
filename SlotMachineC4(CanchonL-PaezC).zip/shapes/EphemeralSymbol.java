public class EphemeralSymbol extends Symbol{
    public static final int DOT = 4;
    private static final int STEP = 6;
    public EphemeralSymbol(String color){super(color, "ephemeral", "deeppink");}
    public void spun(){setSize(Math.max(DOT, getSize() - STEP));}
}