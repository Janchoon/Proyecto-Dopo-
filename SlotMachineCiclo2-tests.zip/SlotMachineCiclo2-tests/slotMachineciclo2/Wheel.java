import java.util.List;
import java.util.Random;

/**
 * una rueda es una posicion de la maquina. Se dibuja en el canva usando
 * dos componentes de "shapes": un rectangulo como el
 * marco/posicion de la rueda y un circulo dentro que muestra
 * un simbolo (identificado por su color)
 *
 * una rueda que aun no ha recibido simbolo (nunca giro/posiciono) no muestra
 * color ("none")
 *
 * @author 
 * @version 1.0 (2026-08)
 */
public class Wheel extends Triangle{

    /** color usado para la rueda normalmente */
    private static final String NORMAL_FRAME = "lightgray";
    /** color usado para la rueda cuando es jackpot */
    private static final String WIN_FRAME = "gold";
    /** valor retornado por getSymbol() cuando no hay ningun simbolo */
    public static final String NONE = "none";

    private static final int FRAME_WIDTH = 50;
    private static final int FRAME_HEIGHT = 80;
    private static final int SYMBOL_DIAMETER = 34;
    private static final int MARGIN_LEFT = 20;
    private static final int SPACING = 60;
    private static final int TOP = 40;

    private Rectangle frame;
    private Circle symbolShape;
    private String symbol;
    private boolean visible;
    
    private boolean locked =false;

    // esta clase da la posicion absoluta de cada figura
    // que se movio, para asi dar la posicion correcta en
    // cada reposicion
    private int frameX = 70, frameY = 15;
    private int symbolX = 20, symbolY = 15;

    /**
     * Crea una nueva rueda sin simbolos añadidos
     * @param Indice de la posicion de esta rueda basado en numeracion 1-etc
     */
    public Wheel(int index){
        frame = new Rectangle();
        symbolShape = new Circle();
        symbol = null;
        visible = false;
        frame.changeColor(NORMAL_FRAME);
        setIndex(index);
    }

    /**
     * Reposiciona esta rueda en el canva a partir de su indice (usado
     * cuando las ruedas son añadidas/removidas y el diseño ha de desplazarse).
     * @param Indice de la posicion de esta rueda basado en numeracion 1-etc
     */
    public void setIndex(int index){
        int x = MARGIN_LEFT + (index - 1) * SPACING;
        frame.changeSize(FRAME_HEIGHT, FRAME_WIDTH);
        frame.moveHorizontal(x - frameX);
        frame.moveVertical(TOP - frameY);
        frameX = x;
        frameY = TOP;

        int sx = x + (FRAME_WIDTH - SYMBOL_DIAMETER) / 2;
        int sy = TOP + (FRAME_HEIGHT - SYMBOL_DIAMETER) / 2;
        symbolShape.changeSize(SYMBOL_DIAMETER);
        symbolShape.moveHorizontal(sx - symbolX);
        symbolShape.moveVertical(sy - symbolY);
        symbolX = sx;
        symbolY = sy;
    }

    /**
     * Hace el simbolo visible para la rueda dado su color, o lo vacia 
     * (no muestra el simbolo) si el color es nulo.
     * @param color un nombre CSS valido, o nulo vaciar el simbolo
     */
    public void setSymbol(String color){
        symbol = color;
        if(color == null){
            symbolShape.makeInvisible();
        } else {
            symbolShape.changeColor(color);
            if(visible) symbolShape.makeVisible();
        }
    }

    /**
     * Elige un simbolo random dado el catalogo y lo muestra
     * @param cataloga la lista de los colores actualmente dados en la maquina
     */
    public void spin(List<String> catalog){
        if(locked) return; //gira o no gira 
        Random random = new Random();
        setSymbol(catalog.get(random.nextInt(catalog.size())));
    }

    /** @retorna el color dado actualmente, o Wheel.NONE si no se da */
    public String getSymbol(){
        return symbol == null ? NONE : symbol;
    }

    /** Marca o repone el marco de la rueda (jackpot) */
    public void highlight(boolean winning){
        frame.changeColor(winning ? WIN_FRAME : NORMAL_FRAME);
        if(visible && symbol != null) symbolShape.makeVisible();
    }

    /** Hace esta rueda (marco y simbolo, si el simbolo es dado) 
    * visible en el canva 
    */
    public void makeVisible(){
        visible = true;
        frame.makeVisible();
        if(symbol != null) symbolShape.makeVisible();
    }

    /** Hace la rueda (marco y simbolo) invisible en el canva */
    public void makeInvisible(){
        visible = false;
        frame.makeInvisible();
        symbolShape.makeInvisible();
    }
    /** 
     * Ciclo2 
    */
    /**Consulta el estado de fijacion de la rueda*/
    public boolean isLocked(){
    return locked;
    }
    
    /**Cambia el estado de bloqueo de la rueda*/
    public void setLocked(boolean locked){
    this.locked = locked;
    }  
      
}
