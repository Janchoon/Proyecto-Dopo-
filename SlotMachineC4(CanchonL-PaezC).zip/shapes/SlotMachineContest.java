import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SlotMachineContest{
    private static SlotMachine lastSimulation;
    public static int[][] solve (int n){
        SlotMachine machine = new SlotMachine(n);
        return solve(machine, n);
    }
    public static void simulate(int n){
        if (lastSimulation != null) {lastSimulation.makeInvisible();}
        SlotMachine machine = new SlotMachine(n);
        int[][] moves = solve(machine, n);
        for (int i = moves.length - 1; i >= 0; i--){
            machine.spin(moves[i][0], n - moves[i][1]);
        }
        machine.makeVisible();
        lastSimulation = machine;
        for (int[] move : moves) {machine.spin(move[0], move[1]);}
    }
    private static int[][] solve(SlotMachine machine, int n){
        Random random = new Random();
        List<int []> moves = new ArrayList<int[]>();
        int distinct = machine.distinctSymbols();
        while (distinct > 1){
            boolean progress = false;
            for (int wheel = 1; wheel <= n && distinct > 1; wheel++){
                int[] seen = scan(machine, n, moves, wheel, distinct);
                int min = min(seen);
                if (seen[0] > min){
                    act(machine, moves, wheel, firstOffset(seen, min));
                    distinct = min;
                    progress = true;
                }
            }
            if (!progress && distinct > 1){
                int wheel = 1 + random.nextInt(n);
                int[] seen = scan(machine, n, moves, wheel, distinct);
                List<Integer> options = new ArrayList<Integer>();
                for (int k = 1; k < n; k++) {if (seen[k] == min(seen)) {options.add(k);}}
                act(machine, moves, wheel, options.get(random.nextInt(options.size())));
            }
        }
        return compress(moves, n);
    }
    private static int[] scan(SlotMachine machine, int n, List<int[]> moves, int wheel, int current){
        int[] seen = new int[n];
        seen[0] = current;
        for (int k = 1; k < n; k++){
            act(machine, moves, wheel, 1);
            seen[k] = machine.distinctSymbols();
        }
        act(machine, moves, wheel, 1);
        return seen;
    }
    private static void act(SlotMachine machine, List<int[]> moves, int wheel, int steps){
        machine.spin(wheel, steps);
        moves.add(new int[]{wheel, steps});
    }
    private static int min(int[] values){
        int result = values[0];
        for (int v : values) {if (v < result) {result = v;}}
        return result;
    }
    private static int firstOffset(int[] seen, int value){
        for (int k = 0; k < seen.length; k++) {if (seen[k] == value) {return k;}}
        return 0;
    }
    private static int[][] compress(List<int[]> moves, int n){
        List<int[]> result = new ArrayList<int[]>();
        for (int[] move : moves){
            int last = result.size() - 1;
            if (last >= 0 && result.get(last)[0] == move[0]){
                result.get(last)[1] = (result.get(last)[1] + move[1]) % n;
            } else {
                result.add(new int[]{move[0], move[1] % n});
            }
        }
        List<int[]> clean = new ArrayList<int[]>();
        for (int[] move : result) {if (move[1] != 0) {clean.add(move);}}
        return clean.toArray(new int[0][]);
    }
}
