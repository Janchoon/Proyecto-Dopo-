import java.util.ArrayList;
import java.util.List;

/**
 * Solucion del problema de maraton (Slot Machine)
 *
 * Hay una maquina de n ruedas y n simbolos. Todas las ruedas tienen los
 * simbolos en el mismo orden circular (el catalogo de la maquina) y cada una
 * muestra uno de ellos. No se puede ver que simbolo muestra cada rueda: solo
 * se puede girar una rueda cualquier numero de pasos y
 * consultar cuantos simbolos DISTINTOS se ven. El objetivo es que todas las
 * ruedas muestren el mismo simbolo (jackpot) con a lo sumo 10 000 acciones
 *
 * @author
 * @version 2.0 (2026-09)
 */
public class SlotMachineContest
{
    /** Maximo numero de acciones que permite la maraton */
    public static final int MAX_ACTIONS = 10000;

    /**
     * Resuelve el problema de la maraton para una maquina de n ruedas y n
     * simbolos, inicializada aleatoriamente. La maquina permanece invisible
     * @param n el numero de ruedas y de simbolos
     * @return la secuencia de acciones {i, j} (rueda i, girada j pasos)
     *         necesarias para ganar. Es vacia si la maquina ya estaba ganada
     */
    public static int[][] solve(int n){
        SlotMachine machine = new SlotMachine(n);
        machine.makeInvisible();
        return solveOn(machine, n);
    }

    /**
     * Simula la solucion: la maquina (n ruedas y n simbolos, inicializada
     * aleatoriamente) se hace visible y se ejecutan sobre ella, con
     * animacion, las acciones necesarias para ganar
     * @param n el numero de ruedas y de simbolos
     */
    public static void simulate(int n){
        SlotMachine machine = new SlotMachine(n);
        machine.makeVisible();
        solveOn(machine, n);
    }

    /**
     * Se separa de solve(int)
     * para que simulate(int) y las pruebas puedan reutilizarlo; solo consulta la
     * maquina con spin(wheel, steps) y distinctSymbols()
     * @param machine maquina con n ruedas y n simbolos
     * @param n       el numero de ruedas y de simbolos
     * @return las acciones {i, j} aplicadas a la maquina
     */
    static int[][] solveOn(SlotMachine machine, int n){
        return new Solver(machine, n).run();
    }

    /**
     * Ejecuta el algoritmo sobre una maquina y va registrando las acciones
     */
    private static class Solver
    {
        private final SlotMachine machine;
        private final int n; //numero dado el cual recibe la maquina para crearse (simbolos y ruedas)
        private final List<int[]> actions;
        /** ultimo valor que reporto distinctSymbols() */
        private int distinct;

        Solver(SlotMachine machine, int n){
            this.machine = machine;
            this.n = n;
            this.actions = new ArrayList<int[]>();
        }

        private int[][] run(){ 
            distinct = machine.distinctSymbols();
            if(!won() && n > 1){
                separate();
                if(!won()) {identifyAndAlign();}
            }
            return actions.toArray(new int[0][]);
        }

        /** Gira la rueda, registra la accion y actualiza el conteo de simbolos distintos */
        private void act(int wheel, int steps){
            machine.spin(wheel, steps);
            actions.add(new int[]{wheel, steps});
            distinct = machine.distinctSymbols();
        }

        /** Todas las ruedas muestran el mismo simbolo (o no hay nada que resolver) */
        private boolean won(){
            return distinct <= 1;
        }

        /**
         * Fase 1: deja las n ruedas mostrando simbolos distintos (distinct == n).
         * Para la rueda w, con las ruedas anteriores ya distintas entre si, el
         * conteo solo puede valer B o B + 1, y vale B + 1 unicamente cuando w
         * queda distinta de todas las demas. Se gira de a un paso hasta que el
         * conteo cambie: si subio, la rueda queda ahi; si bajo, la posicion
         * inicial ya era la buena y se regresa a ella
         */
        private void separate(){
            for(int wheel = 1; wheel <= n && !won() && distinct < n; wheel++){
                int start = distinct;
                int turned = 0;
                while(turned < n && distinct == start){
                    act(wheel, 1);
                    turned++;
                }
                if(won()) return;
                if(distinct < start) act(wheel, -turned);
            }
        }

        /**
         * Fases 2 y 3. Con distinct == n cada simbolo esta en exactamente una
         * rueda. Se toma la posicion inicial de la rueda 1 como origen y
         * offset[w] es la posicion actual de la rueda w respecto a ese origen
         *
         * En el paso s se avanza la rueda 1 hasta la posicion s: choca con la rueda
         * w_s que esta ahi, la posicion s - 1 queda vacia (distinct == n - 1) y
         * la unica rueda que puede llenar ese hueco retrocediendo un paso es w_s
         * Al encontrarla queda en s - 1 y se pasa al siguiente paso
         */
        private void identifyAndAlign(){
            int[] offset = new int[n + 1];
            boolean[] known = new boolean[n + 1];
            known[1] = true;
            int pending = n - 1;   // ruedas (2..n) cuya posicion aun se ignora

            for(int s = 1; s <= n - 2; s++){
                act(1, 1);
                offset[1] = s;
                if(won()) return;

                int left = pending;   // candidatas que faltan por revisar en este paso
                for(int c = 2; c <= n; c++){
                    if(known[c]) continue;
                    if(left > 1){
                        act(c, -1);
                        if(won()) return;
                        if(distinct != n){
                            act(c, 1);   // no era: se devuelve a su lugar
                            left--;
                            continue;
                        }
                    } else {
                        act(c, -1);      // es la unica que queda, no hace falta probar
                        if(won()) return;
                    }
                    known[c] = true;
                    offset[c] = s - 1;
                    pending--;
                    break;
                }
            }

            // la unica rueda sin identificar esta a distancia n - 1 del origen
            for(int c = 2; c <= n; c++){
                if(!known[c]) offset[c] = n - 1;
            }

            // alinear todas con la rueda 1: cada una, con una sola accion
            for(int c = 2; c <= n; c++){
                int steps = Math.floorMod(offset[1] - offset[c], n);
                if(steps > n / 2) steps -= n;
                if(steps != 0){
                    act(c, steps);
                    if(won()) return;
                }
            }
        }
    }
}
