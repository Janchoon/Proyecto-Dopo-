import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

/**
 * Pruebas de unidad del Ciclo 2: intercambiar ruedas (swap), fijar/soltar
 * ruedas (lock/unlock), rotar una rueda un numero de pasos (spin con steps)
 * y dejar la maquina en una configuracion dada (spin con arreglo de simbolos)
 *
 * Todas las pruebas se ejecutan en modo INVISIBLE: nunca se llama a
 * makeVisible(), por lo que no se abre ninguna ventana durante la ejecucion
 * y las llamadas a fail() no muestran JOptionPane
 *
 *
 * @author
 * @version 1.0 (2026-09)
 */
public class SlotMachineC2Test1{

    private SlotMachine machine;

    @Before
    public void setUp(){
        machine = new SlotMachine();
    }

    
    // Metodo auxiliar: crea una maquina con `wheelCount` ruedas vacias y
    // el catalogo de colores dado, en ese orden.
    
    private void buildMachine(int wheelCount, String... colors){
        for(int i = 1; i <= wheelCount; i++) machine.addWheel(i);
        for(int i = 0; i < colors.length; i++) machine.addSymbol(i + 1, colors[i]);
    }

    
    // swap(wheel1, wheel2) - Requisito 9: intercambiar dos ruedas
    

    @Test
    public void swapShouldExchangeTheVisibleSymbolsOfTwoWheels(){
        buildMachine(2, "red", "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");

        machine.swap(1, 2);

        assertTrue("swap valido deberia terminar en ok()", machine.ok());
        assertArrayEquals(new String[]{"blue", "red"}, machine.configuration());
    }

    @Test
    public void swapShouldClampOutOfRangePositionsInsteadOfFailing(){
        buildMachine(2, "red", "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");

        // 0 se acota a 1, y 99 se acota al numero de ruedas (2)
        machine.swap(0, 99);

        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "red"}, machine.configuration());
    }

    @Test
    public void swapShouldDoNothingHarmfulWhenSwappingAWheelWithItself(){
        buildMachine(2, "red", "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");

        machine.swap(1, 1);

        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
    }

    @Test
    public void swapShouldNotSucceedWhenThereAreNoWheels(){
        // maquina recien creada, sin ruedas
        machine.swap(1, 2);

        assertFalse("no deberia poder intercambiar si no hay ruedas", machine.ok());
    }

    
    // lock(wheel) / unlock(wheel) - Requisito 10: fijar y soltar una rueda
    

    @Test
    public void lockShouldPreventASingleSpinFromChangingTheSymbol(){
        buildMachine(1, "red");
        machine.placeSymbol(1, "red");

        machine.lock(1);
        machine.spin(1); // unico color en catalogo: si "girara" seguiria en red,
                          // por eso forzamos con dos colores para distinguir

        assertTrue(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void lockShouldPreventStepSpinFromAdvancingTheWheel(){
        buildMachine(1, "red", "blue", "green");
        machine.placeSymbol(1, "red");

        machine.lock(1);
        machine.spin(1, 5);

        assertTrue("una rueda fijada no deberia fallar, solo no avanzar", machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void unlockShouldAllowStepSpinToAdvanceAgain(){
        buildMachine(1, "red", "blue", "green");
        machine.placeSymbol(1, "red");

        machine.lock(1);
        machine.unlock(1);
        machine.spin(1, 1); // desde "red" (indice 0), un paso -> "blue" (indice 1)

        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void lockShouldNotSucceedWhenThereAreNoWheels(){
        machine.lock(1);
        assertFalse(machine.ok());
    }

    @Test
    public void unlockShouldNotSucceedWhenThereAreNoWheels(){
        machine.unlock(1);
        assertFalse(machine.ok());
    }

    
    // spin(wheel, steps) - Requisito 11: rotar una rueda un numero de pasos
    

    @Test
    public void spinWithStepsShouldAdvanceCyclicallyThroughTheCatalog(){
        buildMachine(1, "red", "blue", "green");
        // la rueda no tiene simbolo aun (NONE); el diseno indica que en ese
        // caso se parte de la posicion 0 ("red") antes de avanzar
        machine.spin(1, 2);

        assertTrue(machine.ok());
        // red(0) -> blue(1) -> green(2)
        assertEquals("green", machine.configuration()[0]);
    }

    @Test
    public void spinWithStepsShouldWrapAroundWhenPassingTheEndOfTheCatalog(){
        buildMachine(1, "red", "blue", "green");
        machine.placeSymbol(1, "green"); // indice 2, el ultimo

        machine.spin(1, 1); // deberia envolver de vuelta a "red" (indice 0)

        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void spinWithStepsShouldNotSucceedWhenThereAreNoSymbolsInTheCatalog(){
        buildMachine(1); // rueda sin catalogo de simbolos

        machine.spin(1, 3);

        assertFalse("no deberia poder girar sin simbolos disponibles", machine.ok());
    }

    @Test
    public void spinWithStepsShouldNotSucceedWhenThereAreNoWheels(){
        machine.addSymbol(1, "red");
        machine.spin(1, 3);

        assertFalse(machine.ok());
    }

    @Test
    public void spinWithZeroStepsShouldLeaveTheSymbolUnchanged(){
        buildMachine(1, "red", "blue");
        machine.placeSymbol(1, "red");

        machine.spin(1, 0);

        assertTrue(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    
    // spin(String[]) - Requisito 12: dejar la maquina en una configuracion dada
    

    @Test
    public void spinWithArrayShouldSetTheGivenConfigurationOnEveryWheel(){
        buildMachine(3, "red", "blue", "green");

        machine.spin(new String[]{"green", "red", "blue"});

        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"green", "red", "blue"}, machine.configuration());
    }

    @Test
    public void spinWithArrayShouldNotChangeLockedWheels(){
        buildMachine(2, "red", "blue", "green");
        machine.placeSymbol(1, "red");
        machine.lock(1);

        machine.spin(new String[]{"blue", "green"});

        assertTrue(machine.ok());
        assertEquals("la rueda fijada no debio cambiar", "red", machine.configuration()[0]);
        assertEquals("green", machine.configuration()[1]);
    }

    @Test
    public void spinWithArrayShouldIgnoreColorsThatAreNotInTheCatalog(){
        buildMachine(1, "red", "blue");
        machine.placeSymbol(1, "red");

        machine.spin(new String[]{"purple"}); // "purple" no esta en el catalogo

        assertTrue("una configuracion con un color invalido no deberia hacer fallar toda la operacion",
                   machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void spinWithArrayShouldUseOnlyAsManyValuesAsThereAreWheels(){
        buildMachine(2, "red", "blue", "green");

        machine.spin(new String[]{"red", "blue", "green"}); // 3 valores, 2 ruedas

        assertTrue(machine.ok());
        assertEquals(2, machine.configuration().length);
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
    }

    @Test
    public void spinWithArrayShouldNotSucceedWhenTheArrayIsNull(){
        buildMachine(1, "red");

        machine.spin((String[]) null);

        assertFalse("un arreglo nulo no es una configuracion valida", machine.ok());
    }

    @Test
    public void spinWithArrayShouldNotSucceedWhenThereAreNoWheels(){
        machine.spin(new String[]{"red"});
        assertFalse(machine.ok());
    }
}
