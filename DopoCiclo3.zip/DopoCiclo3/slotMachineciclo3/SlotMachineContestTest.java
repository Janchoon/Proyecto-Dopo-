import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas de unidad de SlotMachineContest: casos LIMITE del problema de la
 * maraton (n minimo, n maximo y configuraciones iniciales dificiles)
 *
 * Todas las pruebas se ejecutan en modo INVISIBLE: nunca se llama a
 * makeVisible(), por lo que no se abre ninguna ventana
 *
 * Para comprobar que la secuencia devuelta por solve realmente gana, cada
 * prueba (salvo la 1) reproduce las acciones sobre una maquina "gemela" con
 * la misma configuracion inicial y verifica que termina en jackpot
 *
 * @author
 * @version 1.0 (2026-09)
 */
public class SlotMachineContestTest{

    /** Maximo numero de acciones que permite la maraton */
    private static final int MAX_ACTIONS = 10000;

    /** Nombres de color CSS validos (50) para armar maquinas con configuracion propia */
    private static final String[] COLORS = {
        "black", "white", "red", "green", "blue", "yellow", "magenta", "cyan",
        "gray", "orange", "pink", "purple", "brown", "lime", "navy", "teal",
        "olive", "maroon", "silver", "gold", "indigo", "violet", "turquoise",
        "coral", "salmon", "khaki", "orchid", "plum", "tan", "crimson",
        "chocolate", "skyblue", "steelblue", "tomato", "beige", "ivory",
        "lavender", "chartreuse", "aquamarine", "darkred", "darkblue",
        "darkgreen", "darkorange", "darkviolet", "lightblue", "lightgreen",
        "lightgray", "lightyellow", "hotpink", "deeppink"
    };

    // Metodos auxiliares

    /**
     * Crea una maquina de n ruedas y n simbolos (los n primeros de COLORS, en
     * ese orden circular) donde la rueda i (1..n) muestra el simbolo
     * COLORS[shown[i - 1]]
     */
    private SlotMachine build(int n, int[] shown){
        SlotMachine machine = new SlotMachine();
        for(int i = 1; i <= n; i++) machine.addWheel(i);
        for(int i = 0; i < n; i++) machine.addSymbol(i + 1, COLORS[i]);
        String[] configuration = new String[n];
        for(int i = 0; i < n; i++) configuration[i] = COLORS[shown[i]];
        machine.spin(configuration);
        return machine;
    }

    /** Copia exacta (mismo orden de simbolos y misma configuracion) de la maquina dada */
    private SlotMachine twin(SlotMachine machine){
        String[] symbols = machine.symbols();
        String[] configuration = machine.configuration();
        SlotMachine copy = new SlotMachine();
        for(int i = 1; i <= configuration.length; i++) copy.addWheel(i);
        for(int i = 0; i < symbols.length; i++) copy.addSymbol(i + 1, symbols[i]);
        copy.spin(configuration);
        return copy;
    }

    /**
     * Resuelve la maquina dada y comprueba: (a) que ninguna accion apunta a una
     * rueda inexistente ni gira 0 pasos, (b) que no se pasa del limite de
     * acciones y (c) que reproducir la secuencia sobre una copia de la maquina
     * inicial termina en jackpot. Retorna la secuencia de acciones
     */
    private int[][] solveAndVerify(SlotMachine machine, int n){
        SlotMachine initialCopy = twin(machine);
        assertFalse("la configuracion inicial de prueba no debe ser ya jackpot (n > 1)",
                    n > 1 && machine.isJackpot());

        int[][] actions = SlotMachineContest.solveOn(machine, n);

        assertNotNull(actions);
        assertTrue("se paso del limite de " + MAX_ACTIONS + " acciones: " + actions.length,
                   actions.length <= MAX_ACTIONS);
        for(int[] action : actions){
            assertEquals("cada accion es un par {rueda, pasos}", 2, action.length);
            assertTrue("rueda fuera de rango: " + action[0], action[0] >= 1 && action[0] <= n);
            assertTrue("una accion no debe girar 0 pasos", action[1] != 0);
        }
        assertTrue("la maquina resuelta debe quedar en jackpot", machine.isJackpot());

        for(int[] action : actions) initialCopy.spin(action[0], action[1]);
        assertTrue("reproducir las acciones sobre la maquina inicial debe dar jackpot",
                   initialCopy.isJackpot());
        return actions;
    }

    // 1. n en el borde inferior: n = 1 (ya ganada) y valores no validos (n <= 0)

    @Test
    public void solveShouldReturnNoActionsWhenNIsOneOrNotPositive(){
        // con una sola rueda y un solo simbolo la maquina ya esta en jackpot
        int[][] one = SlotMachineContest.solve(1);
        assertNotNull(one);
        assertEquals("con n = 1 no hay nada que hacer", 0, one.length);

        // n no valido: no debe lanzar excepcion ni devolver null
        assertEquals(0, SlotMachineContest.solve(0).length);
        assertEquals(0, SlotMachineContest.solve(-5).length);
        assertEquals(0, SlotMachineContest.solve(Integer.MIN_VALUE).length);
    }

    // 2. n minimo con decision real (n = 2): 300 configuraciones aleatorias

    @Test
    public void solveShouldWinWithTwoWheelsInEveryRandomInitialConfiguration(){
        for(int run = 0; run < 300; run++){
            SlotMachine machine = new SlotMachine(2);
            machine.makeInvisible();
            int[][] actions = solveAndVerify(machine, 2);
            assertTrue("con 2 ruedas se necesitan muy pocas acciones", actions.length <= 10);
        }
    }

    // 3. n maximo de la maraton (n = 50): varias maquinas aleatorias

    @Test
    public void solveShouldWinWithFiftyWheelsWithoutExceedingTheActionLimit(){
        for(int run = 0; run < 10; run++){
            SlotMachine machine = new SlotMachine(50);
            machine.makeInvisible();
            solveAndVerify(machine, 50);
        }
    }

    // 4. Casi jackpot: 49 ruedas muestran el mismo simbolo y una sola es distinta,
    //    y esa esta en el simbolo OPUESTO del circulo (n / 2 pasos de distancia, no
    //    al lado). Es el caso de "separar" con casi todas las ruedas chocando

    @Test
    public void solveShouldWinWhenAllWheelsButOneShowTheSameSymbol(){
        int n = 50;
        for(int odd : new int[]{0, n - 1}){            // la rueda distinta es la 1 y la 50
            int[] shown = new int[n];                  // todas muestran COLORS[0]
            shown[odd] = n / 2;                        // una muestra el simbolo opuesto
            SlotMachine machine = build(n, shown);
            int[][] actions = solveAndVerify(machine, n);
            assertTrue("hay una sola rueda distinta: no se necesitan tantas acciones",
                       actions.length <= 3 * n * n);
        }
    }

    // 5. Permutacion adversa: todas las ruedas ya son distintas y el sucesor de
    //    cada rueda es siempre la de MAYOR indice que queda (la busqueda del
    //    sucesor recorre todos los candidatos). Rueda 1 en la posicion 0 y la
    //    rueda i (i >= 2) en la posicion n - i + 1: n, n-1, ..., 2 -> 1, 2, ..., n-1

    @Test
    public void solveShouldWinWhenEverySuccessorIsTheLastCandidateChecked(){
        for(int n : new int[]{3, 10, 50}){
            int[] shown = new int[n];
            shown[0] = 0;
            for(int i = 2; i <= n; i++) shown[i - 1] = n - i + 1;
            solveAndVerify(build(n, shown), n);
        }
    }
}