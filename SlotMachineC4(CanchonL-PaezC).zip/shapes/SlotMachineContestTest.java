import static org.junit.Assert.*;
import org.junit.Test;
import java.lang.reflect.Method;

/**
 * Pruebas de unidad de SlotMachineContest, centradas en casos extremos.
 * Para fijar una configuracion exacta se usa placeSymbol; solve solo usa
 * spin(wheel, steps) y distinctSymbols().
 */
public class SlotMachineContestTest{


    // solve(machine, n) es private en SlotMachineContest: se invoca por reflexion
    private int[][] solve(SlotMachine machine, int n){
        try{
            Method method = SlotMachineContest.class.getDeclaredMethod("solve", SlotMachine.class, int.class);
            method.setAccessible(true);
            return (int[][]) method.invoke(null, machine, n);
        } catch (Exception e){
            throw new AssertionError("No se pudo invocar solve(machine, n): " + e);
        }
    }

    // Deja la maquina con el simbolo indicado en cada rueda: symbols[k] para la rueda k+1
    private SlotMachine machineWith(int n, int... symbolIndex){
        SlotMachine machine = new SlotMachine(n);
        String[] symbols = machine.symbols();
        for (int i = 0; i < n; i++) {machine.placeSymbol(i + 1, symbols[symbolIndex[i]]);}
        return machine;
    }

    private void assertSolves(SlotMachine machine, int n){
        int[][] moves = solve(machine, n);
        assertEquals("Todas las ruedas deben mostrar el mismo simbolo", 1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());
        assertNotNull(moves);
    }

    @Test
    public void shouldNeedNoActionsWhenThereIsOnlyOneWheel(){
        SlotMachine machine = new SlotMachine(1);
        assertEquals(0, solve(machine, 1).length);
        assertEquals(1, machine.distinctSymbols());
    }

    @Test
    public void shouldSolveTheSmallestMachineWithDifferentSymbols(){
        SlotMachine machine = machineWith(2, 0, 1);
        assertEquals(2, machine.distinctSymbols());
        int[][] moves = solve(machine, 2);
        assertEquals("basta girar una rueda un paso", 1, moves.length);
        assertEquals(1, machine.distinctSymbols());
    }

    @Test
    public void shouldReturnNoActionsForZeroWheels(){
        assertEquals(0, SlotMachineContest.solve(0).length);
    }

    @Test
    public void shouldReturnNoActionsForNegativeSize(){
        assertEquals(0, SlotMachineContest.solve(-5).length);
    }

    @Test
    public void shouldNotMoveAnythingWhenAlreadyWon(){
        SlotMachine machine = machineWith(6, 2, 2, 2, 2, 2, 2);
        String[] before = machine.configuration();
        assertEquals(0, solve(machine, 6).length);
        assertArrayEquals(before, machine.configuration());
    }

    @Test
    public void shouldSolveWhenEveryWheelShowsADifferentSymbol(){
        SlotMachine machine = machineWith(8, 0, 1, 2, 3, 4, 5, 6, 7);
        assertEquals(8, machine.distinctSymbols());
        assertSolves(machine, 8);
    }

    @Test
    public void shouldSolveWhenAllSymbolsAreInPairs(){
        SlotMachine machine = machineWith(6, 0, 0, 1, 1, 2, 2);   // ninguna rueda esta sola
        assertEquals(3, machine.distinctSymbols());
        assertSolves(machine, 6);
    }

    @Test
    public void shouldSolveWhenTwoEqualGroupsCompete(){
        SlotMachine machine = machineWith(6, 0, 0, 0, 1, 1, 1);
        assertEquals(2, machine.distinctSymbols());
        assertSolves(machine, 6);
    }

    @Test
    public void shouldReturnValidActionsForManyRandomMachines(){
        for (int n = 2; n <= 8; n++){
            for (int attempt = 0; attempt < 30; attempt++){
                int[][] moves = SlotMachineContest.solve(n);
                for (int[] move : moves){
                    assertEquals(2, move.length);
                    assertTrue("rueda fuera de rango", move[0] >= 1 && move[0] <= n);
                    assertTrue("pasos fuera de rango", move[1] >= 1 && move[1] <= n - 1);
                }
            }
        }
    }

    @Test
    public void shouldRestoreTheInitialStateWhenActionsAreUndone(){
        for (int attempt = 0; attempt < 30; attempt++){
            int n = 7;
            SlotMachine machine = new SlotMachine(n);
            String[] initial = machine.configuration();
            int[][] moves = solve(machine, n);
            for (int i = moves.length - 1; i >= 0; i--) {machine.spin(moves[i][0], n - moves[i][1]);}
            assertArrayEquals("deshacer debe volver al inicio", initial, machine.configuration());
            for (int[] move : moves) {machine.spin(move[0], move[1]);}
            assertTrue("repetir las acciones debe ganar", machine.isJackpot());
        }
    }
}