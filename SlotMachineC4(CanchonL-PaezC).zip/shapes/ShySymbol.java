public class ShySymbol extends Symbol{
    private boolean shown = true;
    public ShySymbol(String color){super(color, "shy", "darkviolet");}
    public boolean isShown(){return shown;}
    public void selected(){shown = !shown;}
}