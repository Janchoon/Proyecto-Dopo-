import java.util.List;
import java.util.Map;
public class RebelWheel extends Wheel{
    public RebelWheel(int index, List<Wheel> row, Map<String, Symbol> registry){
        super(index, row, registry, "rebel", "firebrick");
    }
    public boolean isManageable(){return false;}
}