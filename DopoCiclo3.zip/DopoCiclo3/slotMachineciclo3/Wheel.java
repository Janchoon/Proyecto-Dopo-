import java.util.List;
import java.util.Random;

/**
 * una rueda es una posicion de la maquina. Se dibuja en el canva usando
 * dos componentes de "shapes": un rectangulo como el
 * marco/posicion de la rueda y un circulo dentro que muestra
 * un simbolo (identificado por su color)
 *
 * una rueda que aun no ha recibido simbolo (nunca giro/posiciono) no muestra
 * color ("none")
 *
 * @author 
 * @version 1.0 (2026-08)
 */
public class Wheel extends Triangle{

    /** color usado para la rueda normalmente */
    private static final String NORMAL_FRAME = "lightgray";
    /** color usado para la rueda cuando es jackpot */
    private static final String WIN_FRAME = "gold";
    /** valor retornado por getSymbol() cuando no hay ningun simbolo */
    public static final String NONE = "none";

    private static final int FRAME_WIDTH = 50;
    private static final int FRAME_HEIGHT = 80;
    private static final int SYMBOL_DIAMETER = 34;
    private static final int MARGIN_LEFT = 20;
    private static final int SPACING = 60;
    private static final int TOP = 40;
    /** pausa (ms) entre paso y paso cuando la rueda gira estando visible */
    private static final int STEP_DELAY = 200;
    private static final Random RANDOM = new Random();

    private Rectangle frame;
    private Circle symbolShape;
    private String symbol;
    private boolean visible;
    
    private boolean locked =false;

    // esta clase da la posicion absoluta de cada figura
    // que se movio, para asi dar la posicion correcta en
    // cada reposicion
    private int frameX = 70, frameY = 15;
    private int symbolX = 20, symbolY = 15;

    /**
     * Crea una nueva rueda sin simbolos añadidos
     * @param Indice de la posicion de esta rueda basado en numeracion 1-etc
     */
    public Wheel(int index){
        frame = new Rectangle();
        symbolShape = new Circle();
        symbol = null;
        visible = false;
        frame.changeColor(NORMAL_FRAME);
        setIndex(index);
    }

    /**
     * Reposiciona esta rueda en el canva a partir de su indice (usado
     * cuando las ruedas son añadidas/removidas y el diseño ha de desplazarse).
     * @param Indice de la posicion de esta rueda basado en numeracion 1-etc
     */
    public void setIndex(int index){
        int x = MARGIN_LEFT + (index - 1) * SPACING;
        frame.changeSize(FRAME_HEIGHT, FRAME_WIDTH);
        frame.moveHorizontal(x - frameX);
        frame.moveVertical(TOP - frameY);
        frameX = x;
        frameY = TOP;

        int sx = x + (FRAME_WIDTH - SYMBOL_DIAMETER) / 2;
        int sy = TOP + (FRAME_HEIGHT - SYMBOL_DIAMETER) / 2;
        symbolShape.changeSize(SYMBOL_DIAMETER);
        symbolShape.moveHorizontal(sx - symbolX);
        symbolShape.moveVertical(sy - symbolY);
        symbolX = sx;
        symbolY = sy;
    }

    /**
     * Hace el simbolo visible para la rueda dado su color, o lo vacia 
     * (no muestra el simbolo) si el color es nulo.
     * @param color un nombre CSS valido, o nulo vaciar el simbolo
     */
    public void setSymbol(String color){
        symbol = color;
        if(color == null){
            symbolShape.makeInvisible();
        } else {
            symbolShape.changeColor(color);
            if(visible) symbolShape.makeVisible();
        }
    }

    /**
     * Gira la rueda un numero aleatorio de pasos (entre 1 y el tamano del
     * catalogo) siguiendo el orden de la lista de simbolos dada. El simbolo
     * resultante NO se elige al azar: es el que corresponde a avanzar esa
     * cantidad de pasos sobre la secuencia
     * @param catalog la secuencia de colores actualmente dada en la maquina
     */
    public void spin(List<String> catalog){
        if(catalog.isEmpty()) return;
        spin(catalog, 1 + RANDOM.nextInt(catalog.size()));
    }

    /**
     * Gira la rueda la cantidad de pasos dada, recorriendo el catalogo de
     * forma ciclica y en su mismo orden. Un paso positivo avanza al siguiente
     * simbolo de la lista; uno negativo retrocede al anterior. Si la rueda esta
     * fijada (locked) no se mueve. Si aun no tiene simbolo, se parte de la
     * posicion 0 de la lista antes de avanzar.
     * Se recorre el catalogo paso a paso (y se hace una pausa por paso si la
     * rueda es visible) pero las vueltas completas se descartan, por lo que
     * un numero de pasos muy grande no toma mas tiempo que uno menor a una vuelta.
     * @param catalog la secuencia de colores actualmente dada en la maquina
     * @param steps   numero de pasos a girar; puede ser negativo o cero
     */
    public void spin(List<String> catalog, int steps){
        if(locked || catalog.isEmpty() || steps == 0) return;

        int size = catalog.size();
        int position = catalog.indexOf(symbol);   // -1 si la rueda esta vacia
        boolean empty = position < 0;
        if(empty){position = 0;};

        int direction = steps > 0 ? 1 : -1;
    
        if(empty) {setSymbol(catalog.get(position));};
        for(int i = 0; i < steps; i++){
            position = Math.floorMod(position + direction, size);
            setSymbol(catalog.get(position));
            if(visible) Canvas.getCanvas().wait(STEP_DELAY);
        }
    }

    /** @retorna el color dado actualmente, o Wheel.NONE si no se da */
    public String getSymbol(){
        return symbol == null ? NONE : symbol;
    }

    /** Marca o repone el marco de la rueda (jackpot) */
    public void highlight(boolean winning){
        frame.changeColor(winning ? WIN_FRAME : NORMAL_FRAME);
        if(visible && symbol != null) symbolShape.makeVisible();
    }

    /** Hace esta rueda (marco y simbolo, si el simbolo es dado) 
    * visible en el canva 
    */
    public void makeVisible(){
        visible = true;
        frame.makeVisible();
        if(symbol != null) symbolShape.makeVisible();
    }

    /** Hace la rueda (marco y simbolo) invisible en el canva */
    public void makeInvisible(){
        visible = false;
        frame.makeInvisible();
        symbolShape.makeInvisible();
    }
    /** 
     * Ciclo2 
    */
    /**Consulta el estado de fijacion de la rueda*/
    public boolean isLocked(){
    return locked;
    }
    
    /**Cambia el estado de bloqueo de la rueda*/
    public void setLocked(boolean locked){
    this.locked = locked;
    }  
      
}
