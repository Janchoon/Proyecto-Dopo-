import java.util.List;
import java.util.Map;
public class LeftyWheel extends Wheel{
    public LeftyWheel(int index, List<Wheel> row, Map<String, Symbol> registry){
        super(index, row, registry, "lefty", "dodgerblue");
    }
    protected void turn(List<String> catalog, int steps){
        Wheel left = leftNeighbor();
        if (left == null){
            super.turn(catalog, steps);
        } else if (left.getSymbol().equals(NONE)){
            setSymbol(null);
        } else {
            select(left.getSymbol());
            finishSpin();
        }
    }
}