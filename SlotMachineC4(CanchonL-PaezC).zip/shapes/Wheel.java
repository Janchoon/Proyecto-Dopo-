import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class Wheel{
    private static final String NORMAL_FRAME = "lightgray";
    private static final String WIN_FRAME = "gold";
    public static final String NONE = "none";
    
    private static final int FRAME_WIDTH = 50;
    private static final int FRAME_HEIGHT = 80;
    private static final int SYMBOL_DIAMETER = 34;
    private static final int MARK = 12; //CICLO 4
    private static final int MARK_INSET = 4; //CICLO 4
    private static final int MARGIN_LEFT = 20;
    private static final int SPACING = 60;
    private static final int TOP = 40;
    
    private static final int STEP_DELAY = 200;
    private static final Random RANDOM = new Random();
    
    private Rectangle frame;
    private Circle symbolShape;
    private Circle symbolMark; //Ciclo 4
    private Rectangle wheelMark; //Ciclo 4
    private String symbol;
    private boolean visible;
    
    private boolean locked = false;
    
    private int frameX = 70, frameY = 15;
    private int symbolX = 20, symbolY = 15;
    
    //Ciclo 4
    private int symbolMarkX = 20, symbolMarkY = 15;
    private int wheelMarkX = 70, wheelMarkY = 15;
    private int diameter = SYMBOL_DIAMETER;
    private int centerX, centerY;
    
    protected final List<Wheel> row;
    private final Map<String, Symbol> registry;
    private String type;
    //Ciclo 4
    public Wheel(int index, List<Wheel> row, Map<String, Symbol> registry, String type, String markColor){
        this.row = row;
        this.registry = registry;
        this.type = type;
        frame = new Rectangle();
        symbolShape = new Circle();
        symbolMark = new Circle();
        wheelMark = new Rectangle();
        symbol = null;
        visible = false;
        frame.changeColor(NORMAL_FRAME);
        wheelMark.changeColor(markColor);
        setIndex(index);
    }
    //Ciclo 1
    public Wheel(int index){ //edit ciclo 4
        this(index, new ArrayList<Wheel>(), new HashMap<String, Symbol>());
    }
    public Wheel(int index, List<Wheel> row, Map<String, Symbol> registry){ //edit ciclo 4
        this(index, row, registry, "normal", "gray");
    }
    public void setIndex(int index){
        int x = MARGIN_LEFT + (index - 1) * SPACING;
        frame.changeSize(FRAME_HEIGHT, FRAME_WIDTH);
        frame.moveHorizontal(x - frameX);
        frame.moveVertical(TOP - frameY);
        frameX = x;
        frameY = TOP;
        
        centerX = x + FRAME_WIDTH / 2; //CICLO 4
        centerY = TOP + FRAME_HEIGHT / 2; //CICLO 4
        int sx = centerX - diameter / 2; //CICLO 4
        int sy = centerY - diameter / 2; //CICLO 4
        symbolShape.changeSize(diameter); //CICLO 4
        symbolShape.moveHorizontal(sx - symbolX);
        symbolShape.moveVertical(sy - symbolY);
        symbolX = sx;
        symbolY = sy;
        
        //CICLO 4
        int mx = x + MARK_INSET;
        int my = TOP + MARK_INSET;
        symbolMark.changeSize(MARK);
        symbolMark.moveHorizontal(mx - symbolMarkX);
        symbolMark.moveVertical(my - symbolMarkY);
        symbolMarkX = mx;
        symbolMarkY = my;
        
        int wx = x + FRAME_WIDTH - MARK - MARK_INSET;
        wheelMark.changeSize(MARK, MARK);
        wheelMark.moveHorizontal(wx - wheelMarkX);
        wheelMark.moveVertical(my - wheelMarkY);
        wheelMarkX = wx;
        wheelMarkY = my;
        drawOnTop();
    }
    public void setSymbol(String color){  //CICLO 4
        if (color == null){
            symbol = null;
            symbolShape.makeInvisible();
            symbolMark.makeInvisible();
        } else{
            show(symbolOf(color)); 
        }
    }
    public void spin(List<String> catalog){
        if (catalog.isEmpty()) {return;}
        spin(catalog, 1 + RANDOM.nextInt(catalog.size()));
    }
    public void spin(List<String> catalog, int steps){ //editado para ciclo 2, 3 y 4
        if(locked || catalog.isEmpty() || steps == 0) return;
        turn(catalog, steps);
    }
    protected void turn(List<String> catalog, int steps){ //CICLO 4
        int size = catalog.size();
        int position = catalog.indexOf(symbol);
        boolean empty = position < 0;
        if (empty) {position = 0;}
        int direction = steps > 0 ? 1 : -1;
        if (empty) {setSymbol(catalog.get(position));}
        for (int i = 0; i < Math.abs(steps); i++){
            position = Math.floorMod(position + direction, size);
            select(catalog.get(position));
            if (visible) {Canvas.getCanvas().wait(STEP_DELAY);}
        }
        finishSpin();
    }
    protected void select(String color){ //CICLO 4
        Symbol chosen = symbolOf(color);
        chosen.selected();
        show(chosen);
    }
    protected void finishSpin(){  //CICLO 4
        if (symbol != null){
            Symbol current = symbolOf(symbol);
            current.spun();
            show(current);
        }
    }
    protected Wheel leftNeighbor(){ //CICLO 4
        int i = row.indexOf(this);
        return i > 0 ? row.get(i - 1) : null;
    }
    public String getSymbol() {return symbol == null ? NONE : symbol;}
    public void highlight(boolean winning){
        frame.changeColor(winning ? WIN_FRAME : NORMAL_FRAME);
        if (visible && symbol != null) {symbolShape.makeVisible();}
        drawOnTop(); //CICLO 4
    }
    public void makeVisible(){
        visible = true;
        frame.makeVisible();
        wheelMark.makeVisible(); //CICLO 4
        if (symbol != null) {symbolShape.makeVisible();}
    }
    public void makeInvisible(){
        visible = false;
        frame.makeInvisible();
        wheelMark.makeInvisible(); //CICLO 4
        symbolShape.makeInvisible();
        symbolMark.makeInvisible(); //CICLO 4
    }
    //Ciclo 2
    public boolean isLocked(){return locked;}
    public void setLocked(boolean locked){this.locked = locked;}
    //CICLO 4
    public String getType(){return type;}
    public boolean isManageable(){return true;}
    private Symbol symbolOf(String color){
        Symbol found = registry.get(color);
        if (found == null){
            found = new Symbol(color);
            registry.put(color, found);
        }
        return found;
    }
    private void show(Symbol shown){
        symbol = shown.getColor();
        symbolShape.changeColor(shown.getColor());
        resize(shown.getSize());
        symbolMark.changeColor(shown.getMarkColor());
        if (visible){
            symbolMark.makeVisible();
            if (shown.isShown()) {symbolShape.makeVisible();} else {symbolShape.makeInvisible();}
        }
    }
    private void resize(int newDiameter){
        if (newDiameter == diameter) {return;}
        int sx = centerX - newDiameter / 2;
        int sy = centerY - newDiameter / 2;
        symbolShape.moveHorizontal(sx - symbolX);
        symbolShape.moveVertical(sy - symbolY);
        symbolX = sx;
        symbolY = sy;
        diameter = newDiameter;
    }
    private void drawOnTop(){
        if (visible){
            wheelMark.makeVisible();
            if (symbol != null){
                symbolMark.makeVisible();
                if (symbolOf(symbol).isShown()) {symbolShape.makeVisible();}
            }
        }
    }
}