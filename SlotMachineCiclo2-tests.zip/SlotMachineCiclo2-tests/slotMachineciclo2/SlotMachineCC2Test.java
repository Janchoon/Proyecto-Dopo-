import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

/**
 * Clase de creacion COLECTIVA (via wiki del curso) para el Ciclo 2.
 * Todas las pruebas de esta clase tambien se ejecutan en modo INVISIBLE
 *
 * @author Cl-Pc
 * @version 1.0 (2026-09)
 */
public class SlotMachineCC2Test{

    private SlotMachine machine;

    @Before
    public void setUp(){
        machine = new SlotMachine();
    }

    // EJEMPLO 1 
    // "que deberia hacer": intercambiar dos ruedas debe conservar el numero
    // de simbolos distintos en el catalogo (swap no toca el catalogo)
    
    @Test
    public void accordingClPcShouldKeepDistinctSymbolCountAfterSwap(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");

        int before = machine.distinctSymbols();
        machine.swap(1, 2);
        int after = machine.distinctSymbols();

        assertTrue(machine.ok());
        assertEquals("swap no deberia alterar el catalogo de simbolos", before, after);
    }

    // EJEMPLO 2 
    // "que NO deberia hacer": dejar una configuracion dada (spin con
    // arreglo) no deberia declarar jackpot si los simbolos asignados no
    // coinciden entre si.
    
    @Test
    public void accordingClPcShouldNotReportJackpotWhenSetConfigurationDiffers(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.spin(new String[]{"red", "blue"});

        assertTrue(machine.ok());
        assertFalse("simbolos distintos en las ruedas no es jackpot", machine.isJackpot());
    }


}
