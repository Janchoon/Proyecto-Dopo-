import static org.junit.Assert.*;
import org.junit.Test;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Pruebas de unidad del ciclo 4: tipos de ruedas (lefty, rebel, double) y de
 * simbolos (ephemeral, shy). Todas se ejecutan con la maquina invisible.
 */
public class SlotMachineC4Test{

    // Maquina con los simbolos red, blue y green (normales).
    private SlotMachine machine(){
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        return machine;
    }

    // El registro interno de simbolos de la maquina, para mirar los que se registraron.
    @SuppressWarnings("unchecked")
    private Map<String, Symbol> registryOf(SlotMachine machine){
        try{
            Field field = SlotMachine.class.getDeclaredField("registry");
            field.setAccessible(true);
            return (Map<String, Symbol>) field.get(machine);
        } catch (Exception e){
            throw new AssertionError("No se pudo leer el registro: " + e);
        }
    }

    //-------------------------------------------------- addWheel(type, pos) y addSymbol(type, pos, color)

    @Test
    public void shouldRejectAnUnknownWheelType(){
        SlotMachine machine = machine();
        machine.addWheel("flying", 1);
        assertFalse(machine.ok());
        assertEquals(0, machine.configuration().length);
    }

    @Test
    public void shouldRejectAnUnknownSymbolType(){
        SlotMachine machine = machine();
        machine.addSymbol("ghost", 1, "pink");
        assertFalse(machine.ok());
        assertEquals(3, machine.symbols().length);
    }

    @Test
    public void shouldAcceptTypeNamesInAnyCase(){
        SlotMachine machine = machine();
        machine.addWheel("LEFTY", 1);
        machine.addSymbol("Shy", 1, "pink");
        assertTrue(machine.ok());
        assertEquals(1, machine.configuration().length);
        assertEquals(4, machine.symbols().length);
    }

    @Test
    public void shouldKeepTheValidationsOfTheColorWhenAddingATypedSymbol(){
        SlotMachine machine = machine();
        machine.addSymbol("shy", 1, "notacolor");
        assertFalse(machine.ok());
        machine.addSymbol("shy", 1, "red");           // ya existe
        assertFalse(machine.ok());
        assertEquals(3, machine.symbols().length);
    }

    @Test
    public void shouldClampThePositionOfTypedElements(){
        SlotMachine machine = machine();
        machine.addSymbol("shy", 99, "pink");
        machine.addSymbol("ephemeral", 0, "gold");
        String[] symbols = machine.symbols();
        assertEquals("pink", symbols[symbols.length - 1]);
        assertEquals("gold", symbols[0]);
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 99);
        assertEquals(2, machine.configuration().length);
    }

    @Test
    public void shouldKeepTheOldAddMethodsWorkingAfterTypedOnes(){
        SlotMachine machine = new SlotMachine();
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol(2, "blue");
        machine.addWheel("rebel", 1);
        machine.addWheel(2);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        assertTrue(machine.ok());
        assertEquals(Arrays.asList("red", "blue"), Arrays.asList(machine.configuration()));
    }

    @Test
    public void shouldRegisterTheTypeOfTheSymbols(){
        SlotMachine machine = new SlotMachine();
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol("ephemeral", 2, "blue");
        machine.addSymbol(3, "green");
        Map<String, Symbol> registry = registryOf(machine);
        assertEquals("shy", registry.get("red").getType());
        assertEquals("ephemeral", registry.get("blue").getType());
        assertEquals("normal", registry.get("green").getType());
    }

    //-------------------------------------------------- tipos de rueda

    @Test
    public void leftyShouldCopyTheSymbolOfTheWheelOnItsLeft(){
        SlotMachine machine = machine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.spin(2);
        assertEquals("red", machine.configuration()[1]);
    }

    @Test
    public void leftyShouldFollowItsNewLeftNeighbourAfterASwap(){
        SlotMachine machine = machine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("normal", 3);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.placeSymbol(3, "green");
        machine.swap(2, 3);                 // ahora: normal(red), normal(green), lefty(blue)
        machine.spin(3);
        assertEquals("green", machine.configuration()[2]);
    }

    @Test
    public void leftyWithoutALeftWheelShouldSpinAsANormalOne(){
        SlotMachine machine = machine();
        machine.addWheel("lefty", 1);
        machine.placeSymbol(1, "red");
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void leftyShouldBecomeEmptyWhenItsLeftWheelIsEmpty(){
        SlotMachine machine = machine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.placeSymbol(2, "blue");
        machine.spin(2);
        assertEquals(Wheel.NONE, machine.configuration()[1]);
    }

    @Test
    public void rebelShouldNotAllowToBeLocked(){
        SlotMachine machine = machine();
        machine.addWheel("rebel", 1);
        machine.placeSymbol(1, "red");
        machine.lock(1);
        assertFalse(machine.ok());
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);   // sigue girando
    }

    @Test
    public void rebelShouldNotAllowToBeSwapped(){
        SlotMachine machine = machine();
        machine.addWheel("rebel", 1);
        machine.addWheel("normal", 2);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.swap(1, 2);
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]);
        assertEquals("blue", machine.configuration()[1]);
    }

    @Test
    public void rebelShouldNotAllowToBeSwappedAsTheSecondWheelEither(){
        SlotMachine machine = machine();
        machine.addWheel("normal", 1);
        machine.addWheel("rebel", 2);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.swap(1, 2);
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void rebelShouldNotAllowToBeDeleted(){
        SlotMachine machine = machine();
        machine.addWheel("rebel", 1);
        machine.delWheel(1);
        assertFalse(machine.ok());
        assertEquals(1, machine.configuration().length);
    }

    @Test
    public void otherWheelsShouldStillBeLockedSwappedAndDeleted(){
        SlotMachine machine = machine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("double", 3);
        machine.lock(1);
        assertTrue(machine.ok());
        machine.swap(2, 3);
        assertTrue(machine.ok());
        machine.delWheel(1);
        assertTrue(machine.ok());
        assertEquals(2, machine.configuration().length);
    }

    @Test
    public void doubleShouldSpinTwiceTheNumberOfWheelsIgnoringTheRequestedSteps(){
        SlotMachine machine = machine();          // 3 simbolos
        machine.addWheel("double", 1);
        machine.addWheel("normal", 2);            // 2 ruedas -> 4 pasos -> 4 mod 3 = 1
        machine.placeSymbol(1, "red");
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);
        machine.placeSymbol(1, "red");
        machine.spin(1, 100);                     // los pasos pedidos no importan
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void doubleShouldGrowItsSpinWhenWheelsAreAdded(){
        SlotMachine machine = machine();
        machine.addWheel("double", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("normal", 3);
        machine.addWheel("normal", 4);            // 4 ruedas -> 8 pasos -> 8 mod 3 = 2
        machine.placeSymbol(1, "red");
        machine.spin(1, 1);
        assertEquals("green", machine.configuration()[0]);
    }

    @Test
    public void doubleShouldReturnToItsSymbolWhenWheelsAndSymbolsAreEqual(){
        SlotMachine machine = machine();
        machine.addWheel("double", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("normal", 3);            // 3 ruedas -> 6 pasos -> 6 mod 3 = 0
        machine.placeSymbol(1, "blue");
        machine.spin(1);
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void doubleShouldNotSpinWhenLocked(){
        SlotMachine machine = machine();
        machine.addWheel("double", 1);
        machine.addWheel("normal", 2);
        machine.placeSymbol(1, "red");
        machine.lock(1);
        machine.spin(1, 1);
        assertEquals("red", machine.configuration()[0]);
    }

    //-------------------------------------------------- tipos de simbolo

    @Test
    public void ephemeralShouldShrinkEachSpinDownToADot(){
        Symbol symbol = new EphemeralSymbol("red");
        int previous = symbol.getSize();
        assertEquals(Symbol.FULL_SIZE, previous);
        for (int i = 0; i < 3; i++){
            symbol.spun();
            assertTrue(symbol.getSize() < previous);
            previous = symbol.getSize();
        }
        for (int i = 0; i < 50; i++) {symbol.spun();}
        assertEquals(EphemeralSymbol.DOT, symbol.getSize());   // nunca baja del punto
    }

    @Test
    public void shyShouldAlternateItsVisibilityEachTimeItIsSelected(){
        Symbol symbol = new ShySymbol("red");
        assertTrue(symbol.isShown());
        symbol.selected();
        assertFalse(symbol.isShown());
        symbol.selected();
        assertTrue(symbol.isShown());
    }

    @Test
    public void normalSymbolShouldNeverChange(){
        Symbol symbol = new Symbol("red");
        for (int i = 0; i < 10; i++) {symbol.selected(); symbol.spun();}
        assertEquals(Symbol.FULL_SIZE, symbol.getSize());
        assertTrue(symbol.isShown());
    }

    @Test
    public void aWheelShouldMakeAShySymbolAlternateEachTimeItSelectsIt(){
        List<String> catalog = Arrays.asList("red", "blue");
        Map<String, Symbol> registry = new HashMap<String, Symbol>();
        Symbol shy = new ShySymbol("red");
        registry.put("red", shy);
        Wheel wheel = new Wheel(1, new ArrayList<Wheel>(), registry);
        wheel.setSymbol("blue");
        wheel.spin(catalog, 1);                   // escoge red
        assertFalse(shy.isShown());
        wheel.spin(catalog, 2);                   // blue y otra vez red
        assertTrue(shy.isShown());
    }

    @Test
    public void aWheelShouldShrinkAnEphemeralSymbolOncePerSpinNotPerStep(){
        List<String> catalog = Arrays.asList("red", "blue");
        Map<String, Symbol> registry = new HashMap<String, Symbol>();
        Symbol ephemeral = new EphemeralSymbol("red");
        registry.put("red", ephemeral);
        Wheel wheel = new Wheel(1, new ArrayList<Wheel>(), registry);
        wheel.setSymbol("blue");
        wheel.spin(catalog, 3);                   // red, blue, red: termina en red
        assertEquals(Symbol.FULL_SIZE - 6, ephemeral.getSize());
        wheel.spin(catalog, 2);                   // blue, red
        assertEquals(Symbol.FULL_SIZE - 12, ephemeral.getSize());
    }

    @Test
    public void aHiddenShySymbolShouldStillCountForTheJackpot(){
        SlotMachine machine = new SlotMachine();
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol("normal", 2, "blue");
        machine.addWheel("normal", 1);
        machine.addWheel("normal", 2);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "red");
        machine.spin(1, 2);                        // blue y red: lo oculta o lo muestra
        machine.spin(1, 2);
        assertTrue(machine.isJackpot());
        assertEquals(1, machine.distinctSymbols());
    }

    @Test
    public void typedSymbolsShouldBehaveOnAWheelCreatedWithTheOldAddWheel(){
        SlotMachine machine = new SlotMachine();
        machine.addSymbol("ephemeral", 1, "red");
        machine.addSymbol(2, "blue");
        machine.addWheel(1);                       // addWheel(int): rueda normal de siempre
        machine.placeSymbol(1, "blue");
        machine.spin(1, 1);                        // termina en red
        assertEquals("red", machine.configuration()[0]);
        assertEquals(Symbol.FULL_SIZE - 6, registryOf(machine).get("red").getSize());
    }

    @Test
    public void differentTypesShouldHaveDifferentMarkers(){
        String[] colors = {new Symbol("red").getMarkColor(), new EphemeralSymbol("red").getMarkColor(),
                           new ShySymbol("red").getMarkColor()};
        for (int i = 0; i < colors.length; i++){
            for (int j = i + 1; j < colors.length; j++) {assertNotEquals(colors[i], colors[j]);}
        }
        List<Wheel> row = new ArrayList<Wheel>();
        Map<String, Symbol> registry = new HashMap<String, Symbol>();
        String[] types = {new Wheel(1).getType(), new LeftyWheel(1, row, registry).getType(),
                          new RebelWheel(1, row, registry).getType(), new DoubleWheel(1, row, registry).getType()};
        for (int i = 0; i < types.length; i++){
            for (int j = i + 1; j < types.length; j++) {assertNotEquals(types[i], types[j]);}
        }
    }
}
