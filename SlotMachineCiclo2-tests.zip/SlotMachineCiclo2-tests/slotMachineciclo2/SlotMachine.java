import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * SlotMachine simula una maquina de apuestas (tragamonedas): maneja un
 * conjunto de ruedas y catalogo de simbolos (identificados por nombres CSS)
 * que pueden ser dados a las ruedas, "girados", y verificados en caso de 
 * ganar
 *
 * Esta clase es solo un simulador o intento de ello
 * no tiene una interfaz grafica a la talla de un buen simulador
 *
 * Design notes:
 * - Las posiciones empiezan en 1, si es menor a 1 se toma 1, y si es mayor
 * al valor maximo, se toma el valor maximo.
 * - Los simbolos son identificador por el color; Colores han de ser nombres
 * CSS validos y diferentes en el catalogo para funcionar
 * 
 * - {@link #ok()} reporta si la operacion anterior fue exitosa
 * @author
 * @version 1.0 (2026-08)
 */
public class SlotMachine{

    private List<Wheel> wheels;
    private List<String> catalog;
    private boolean visible;
    private boolean everShown;
    private boolean lastOk;

    /**
     * Crea una nueva maquina sin ruedas ni simbolos dados
     */
    public SlotMachine(){
        wheels = new ArrayList<Wheel>();
        catalog = new ArrayList<String>();
        visible = false;
        lastOk = true;
    }

    /**
     * Añade una nueva rueda (vacia) en la posicion dada
     * @param pos es la posicion deseada
     */
    public void addWheel(int pos){
        int index = clamp(pos, wheels.size() + 1);
        Wheel wheel = new Wheel(index);
        wheels.add(index - 1, wheel);
        reindexWheels();
        if(visible) wheel.makeVisible();
        succeed();
    }

    /**
     * Remueve la rueda de la posicion dada
     * @param pos es la posicion de la rueda a remover
     */
    public void delWheel(int pos){
        if(wheels.isEmpty()){
            fail("No hay ruedas para eliminar.");
            return;
        }
        int index = clamp(pos, wheels.size());
        Wheel removed = wheels.remove(index - 1);
        removed.makeInvisible();
        reindexWheels();
        succeed();
    }

    /**
     * Añade un nuevo simbolo (un color CSS que no se usa actualmente en el 
     * catalogo) en una posicion dada
     * @param pos  la posicion de 1-etc deseada (no influye en la suerte)
     * @param un color CSS valido pero no repetido
     */
    public void addSymbol(int pos, String color){
        if(!SlotMachine.isValid(color)){
            fail("\"" + color + "\" no es un color estandar CSS.");
            return;
        }
        String normalized = color.toLowerCase();
        if(catalog.contains(normalized)){
            fail("El color \"" + color + "\" ya existe; los simbolos deben ser de colores diferentes.");
            return;
        }
        int index = clamp(pos, catalog.size() + 1);
        catalog.add(index - 1, normalized);
        succeed();
    }

    /**
     * Remueve el simbolo del color dado del catalogo
     * y lo elminina de cualquier rueda que lo tenga
     * @param symbol el color identificando el simbolo para eliminarlo
     */
    public void delSymbol(String symbol){
        String normalized = symbol == null ? null : symbol.toLowerCase();
        if(!catalog.remove(normalized)){
            fail("El simbolo \"" + symbol + "\" no existe en la maquina.");
            return;
        }
        for(Wheel wheel : wheels){
            if(wheel.getSymbol().equals(normalized)) wheel.setSymbol(null);
        }
        refreshJackpotHighlight();
        succeed();
    }

    /**
     * Da el simbolo visible a una rueda (sin girar).
     * @param wheel  la posicion de 1-etc de la rueda
     * @param symbol el color del simbolo a dar; ha de existir en el catalogo
     */
    public void placeSymbol(int wheel, String symbol){
        String normalized = symbol == null ? null : symbol.toLowerCase();
        if(wheels.isEmpty()){
            fail("No hay ruedas en la maquina.");
            return;
        }
        if(!catalog.contains(normalized)){
            fail("El simbolo \"" + symbol + "\" no existe en la maquina.");
            return;
        }
        int index = clamp(wheel, wheels.size());
        wheels.get(index - 1).setSymbol(normalized);
        refreshJackpotHighlight();
        succeed();
    }

    /**
     * Gira una sola rueda, mostrando un simbolo random del catalogo
     * @param wheel la posicion de 1-etc de la rueda para girar
     */
    public void spin(int wheel){
        if(!canSpin()) return;
        int index = clamp(wheel, wheels.size());
        wheels.get(index - 1).spin(catalog);
        refreshJackpotHighlight();
        succeed();
    }

    /**
     * Gira cada rueda de la maquina
     */
    public void spin(){
        if(!canSpin()) return;
        for(Wheel wheel : wheels) wheel.spin(catalog);
        refreshJackpotHighlight();
        succeed();
    }

    /** @retorna los colores de los simbolos en la maquina, en orden ascendente */
    public String[] symbols(){
        succeed();
        return catalog.toArray(new String[0]);
    }

    /** @retorna el numero de simbolos distintos en el catalogo actual */
    public int distinctSymbols(){
        succeed();
        return new HashSet<String>(catalog).size();
    }

    /** @retorna los colores visibles actualmente en las ruedas, de izquierda a derecha */
    public String[] configuration(){
        succeed();
        String[] result = new String[wheels.size()];
        for(int i = 0; i < wheels.size(); i++) result[i] = wheels.get(i).getSymbol();
        return result;
    }

    /** @retorna true si la configuracion actual es jackpot */
    public boolean isJackpot(){
        succeed();
        return computeJackpot();
    }

    /** Hace todo el simulador visible (todas las ruedas) */
    public void makeVisible(){
        visible = true;
        everShown = true;
        for(Wheel wheel : wheels) wheel.makeVisible();
        succeed();
    }

    /** Hace todo el simulador invisible (todas las ruedas), sigue funcionando */
    public void makeInvisible(){
        visible = false;
        for(Wheel wheel : wheels) wheel.makeInvisible();
        succeed();
    }

    /** Termina el simulador y cierra la ventana del canva, si era visible */
    public void exit(){
        makeInvisible();
        if(everShown) Canvas.getCanvas().setVisible(false);
        succeed();
    }

    /** @retorna si la ultima operacion se logro */
    public boolean ok(){
        return lastOk;
    }

    
    /**Metodos ciclo2
     *
    */
    public void swap(int wheel1, int wheel2){
        if(wheels.isEmpty()){
            fail("No hay ruedas");
            return;
        }
        int idx1 = clamp(wheel1, wheels.size()) -1;
        int idx2 = clamp(wheel2, wheels.size()) -1;
        if (idx1 ==idx2){
            succeed();
            return;
        }
        // Intercambio fisico dentro de la lista de ruedas
        Wheel temp = wheels.get(idx1);
        wheels.set(idx1, wheels.get(idx2));
        wheels.set(idx2, temp);
        
        // Actualiza el posicionamiento visual y el estado de jackpot
        reindexWheels();
        refreshJackpotHighlight();
        succeed();
        
    }
    
    /** Fija la rueda para que no haya ningun giro*/
    public void lock(int wheel){
        if (wheels.isEmpty()){
            fail("No hay ruedas");
            return;
        }
        int index = clamp(wheel, wheels.size());
        wheels.get(index-1).setLocked(true);
        succeed();
    }
    
    /** desbloquea la rueda para que pueda girar*/ 
    public void unlock(int wheel){
        if (wheels.isEmpty()){
            fail("No hay ruedas");
            return;
        }
        int index = clamp(wheel, wheels.size());
        wheels.get(index-1).setLocked(false);
        succeed();
    }
    
    public void spin(int wheel, int steps){
        if(!canSpin()) return;
        
        int index = clamp(wheel, wheels.size());
        Wheel selectedWheel = wheels.get(index -1);
        
        //con la rueda bloqueada no puede girar
        if(selectedWheel.isLocked()){
            succeed();
            return;
        }
        //revisa la posicion del simbolo
        String currentSymbol = selectedWheel.getSymbol();
        int currentPos = catalog.indexOf(currentSymbol);
        
        //si no hay simbolo que lo ponga en la pos 0
        if(currentPos == -1) currentPos = 0;
        
        //avanza en la lista de forma ciclica 
        for(int i = 0; i<steps; i++){
            currentPos = (currentPos + 1) % catalog.size();
            selectedWheel.setSymbol(catalog.get(currentPos));
            
            // que haga la animacion paso a paso 
            if(visible){
                Canvas.getCanvas().wait(200);
                
            }
         }
        
        refreshJackpotHighlight();
        succeed();
    }
    
    /**
     *  Arreglo con los nombres de los colores/simbolos a establecer en las ruedas.
     */
    public void spin(String[] setSymbols){
        if(wheels.isEmpty()){
            fail("No hay ruedas en la maquina.");
            return;
        }
        if(setSymbols == null){
            fail("El arreglo de simbolos no puede ser nulo.");
            return;
        }

        int limit = Math.min(wheels.size(), setSymbols.length);
        
        for(int i = 0; i < limit; i++){
            Wheel wheel = wheels.get(i);
            
            //Bloqueada no cambia simbolo
            if(wheel.isLocked()) continue;

            String symbol = setSymbols[i] == null ? null : setSymbols[i].toLowerCase();
            
            // Solo asigna el simbolo si existe en el catalogo
            if(symbol != null && catalog.contains(symbol)){
                wheel.setSymbol(symbol);
            }
        }

        refreshJackpotHighlight();
        succeed();
    }
    
    
    private static final Map<String,Color> NAMES = new HashMap<String,Color>();

    static{
        put("black",0,0,0);         put("white",255,255,255);
        put("red",255,0,0);         put("green",0,128,0);
        put("blue",0,0,255);        put("yellow",255,255,0);
        put("magenta",255,0,255);   put("cyan",0,255,255);
        put("gray",128,128,128);    put("grey",128,128,128);
        put("orange",255,165,0);    put("pink",255,192,203);
        put("purple",128,0,128);    put("brown",165,42,42);
        put("lime",0,255,0);        put("navy",0,0,128);
        put("teal",0,128,128);      put("olive",128,128,0);
        put("maroon",128,0,0);      put("silver",192,192,192);
        put("gold",255,215,0);      put("indigo",75,0,130);
        put("violet",238,130,238);  put("turquoise",64,224,208);
        put("coral",255,127,80);    put("salmon",250,128,114);
        put("khaki",240,230,140);   put("orchid",218,112,214);
        put("plum",221,160,221);    put("tan",210,180,140);
        put("crimson",220,20,60);   put("chocolate",210,105,30);
        put("skyblue",135,206,235); put("steelblue",70,130,180);
        put("tomato",255,99,71);    put("beige",245,245,220);
        put("ivory",255,255,240);   put("lavender",230,230,250);
        put("chartreuse",127,255,0);put("aquamarine",127,255,212);
        put("darkred",139,0,0);     put("darkblue",0,0,139);
        put("darkgreen",0,100,0);   put("darkorange",255,140,0);
        put("darkviolet",148,0,211);put("lightblue",173,216,230);
        put("lightgreen",144,238,144);put("lightgray",211,211,211);
        put("lightyellow",255,255,224);put("hotpink",255,105,180);
        put("deeppink",255,20,147); put("firebrick",178,34,34);
        put("forestgreen",34,139,34);put("seagreen",46,139,87);
        put("slateblue",106,90,205);put("royalblue",65,105,225);
        put("midnightblue",25,25,112);put("mediumpurple",147,112,219);
        put("mediumblue",0,0,205);  put("mediumseagreen",60,179,113);
        put("peru",205,133,63);     put("sienna",160,82,45);
        put("wheat",245,222,179);   put("thistle",216,191,216);
        put("azure",240,255,255);   put("honeydew",240,255,240);
        put("mintcream",245,255,250);put("mistyrose",255,228,225);
        put("moccasin",255,228,181);put("navajowhite",255,222,173);
        put("orangered",255,69,0);  put("palegreen",152,251,152);
        put("paleturquoise",175,238,238);put("peachpuff",255,218,185);
        put("powderblue",176,224,230);put("rosybrown",188,143,143);
        put("saddlebrown",139,69,19);put("sandybrown",244,164,96);
        put("seashell",255,245,238);put("slategray",112,128,144);
        put("springgreen",0,255,127);put("yellowgreen",154,205,50);
        put("indianred",205,92,92); put("darkkhaki",189,183,107);
        put("darkcyan",0,139,139);  put("darkgoldenrod",184,134,11);
        put("darkgray",169,169,169);put("darkmagenta",139,0,139);
        put("darkolivegreen",85,107,47);put("darksalmon",233,150,122);
        put("darkslateblue",72,61,139);put("darkslategray",47,79,79);
        put("darkturquoise",0,206,209);put("deepskyblue",0,191,255);
        put("dodgerblue",30,144,255);put("cornflowerblue",100,149,237);
        put("cadetblue",95,158,160);put("burlywood",222,184,135);
        put("blueviolet",138,43,226);put("aliceblue",240,248,255);
        put("antiquewhite",250,235,215);put("greenyellow",173,255,47);
        put("lightcoral",240,128,128);put("lightcyan",224,255,255);
        put("lightpink",255,182,193);put("lightsalmon",255,160,122);
        put("lightseagreen",32,178,170);put("lightskyblue",135,206,250);
        put("lightsteelblue",176,196,222);put("limegreen",50,205,50);
    }

    private static void put(String name, int r, int g, int b){
        NAMES.put(name, new Color(r,g,b));
    }

    /**
     * Indica si el nombre de color dado es reconocido en CSS
     * @param colorName el nombre a validar
     * @retorna true si el color es valido
     */
    public static boolean isValid(String colorName){
        return colorName != null && NAMES.containsKey(colorName.toLowerCase());
    }

    /**
     * Traduce el color CSS en java.awt.Color equivalente
     * @param colorName el nombre de color CSS
     * @retorna el color correspondiente, negro si es desconocido
     */
    public static Color toAwtColor(String colorName){
        Color c = colorName == null ? null : NAMES.get(colorName.toLowerCase());
        return c == null ? Color.black : c;
    }
    
    
    // Metodos privados de apoyo
    
    private boolean canSpin(){
        if(wheels.isEmpty()){
            fail("No hay ruedas en la maquina.");
            return false;
        }
        if(catalog.isEmpty()){
            fail("No hay simbolos disponibles para girar.");
            return false;
        }
        return true;
    }

    private boolean computeJackpot(){
        if(wheels.isEmpty()) return false;
        String first = wheels.get(0).getSymbol();
        if(first.equals(Wheel.NONE)) return false;
        for(Wheel wheel : wheels){
            if(!wheel.getSymbol().equals(first)) return false;
        }
        return true;
    }

    private void refreshJackpotHighlight(){
        boolean winning = computeJackpot();
        for(Wheel wheel : wheels) wheel.highlight(winning);
    }

    private void reindexWheels(){
        for(int i = 0; i < wheels.size(); i++) wheels.get(i).setIndex(i + 1);
    }

    private int clamp(int pos, int max){
        if(pos < 1) return 1;
        if(pos > max) return max;
        return pos;
    }

    private void succeed(){
        lastOk = true;
    }

    private void fail(String message){
        lastOk = false;
        if(visible){
            JOptionPane.showMessageDialog(null, message, "Slot Machine",
                                           JOptionPane.WARNING_MESSAGE);
        }
    }
}
