public class Symbol{
    public static final int FULL_SIZE = 34;
    private final String color;
    private final String type;
    private final String markColor;
    private int size;
    public Symbol(String color){
        this(color, "normal", "black");
    }
    protected Symbol(String color, String type, String markColor){
        this.color = color;
        this.type = type;
        this.markColor = markColor;
        size = FULL_SIZE;
    }
    public String getColor(){return color;}
    public String getType(){return type;}
    public String getMarkColor(){return markColor;}
    public int getSize(){return size;}
    protected void setSize(int newSize){size = newSize;}
    public boolean isShown(){return true;}
    public void selected(){}
    public void spun(){}
}